<script setup>
import { ref, onMounted } from 'vue'

const status = ref('Načítavam...')
const teams = ref([])
const teamsError = ref('')

onMounted(async () => {
  try {
    const response = await fetch('/api/v1/health')
    const data = await response.json()

    if (response.ok) {
      status.value = data.status.toUpperCase()
    } else {
      status.value = 'ERROR'
    }
  } catch (error) {
    status.value = 'ERROR'
  }

  try {
    const response = await fetch('/api/v1/teams')
    if (!response.ok) throw new Error('Failed to load teams')
    teams.value = await response.json()
  } catch (error) {
    teamsError.value = error.message
  }
})
</script>

<template>
  <div class="app">
    <h1>Think different Academy</h1>
    <p>Status: {{ status }}</p>

    <table v-if="teams.length" class="teams">
      <thead>
        <tr>
          <th>Team</th>
          <th>Member 1</th>
          <th>Member 2</th>
          <th>Member 3</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="team in teams" :key="team.id">
          <td>{{ team.team_name }}</td>
          <td>{{ team.member1 }}</td>
          <td>{{ team.member2 }}</td>
          <td>{{ team.member3 }}</td>
        </tr>
      </tbody>
    </table>
    <p v-else-if="teamsError" class="error">{{ teamsError }}</p>
    <p v-else>No teams yet.</p>
  </div>
</template>

<style scoped>
.app {
  text-align: center;
  margin-top: 150px;
}

h1 {
  color: #000000;
  font-size: 60px;
}

p {
  font-size: 32px;
}

.teams {
  margin: 40px auto 0;
  border-collapse: collapse;
  font-size: 18px;
}

.teams th,
.teams td {
  border: 1px solid #ccc;
  padding: 8px 16px;
}

.error {
  color: #c00;
}
</style>