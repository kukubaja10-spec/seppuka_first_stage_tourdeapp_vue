import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'
import 'dotenv/config'
import pool from './db.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const PORT = process.env.PORT || 3000

app.use(express.json())

app.get('/api/v1/health', (req, res) => {
  res.status(200).json({
    status: 'ok'
  })
})

// GET
app.get('/api/v1/items/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM items WHERE id = ?', [req.params.id])
    if (rows.length === 0) return res.status(404).json({ error: 'Not found' })
    res.json(rows[0])
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// CREATE
app.post('/api/v1/items', async (req, res) => {
  try {
    const { name } = req.body
    if (!name) return res.status(400).json({ error: 'name is required' })
    const [result] = await pool.query('INSERT INTO items (name) VALUES (?)', [name])
    res.status(201).json({ id: result.insertId, name })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// UPDATE
app.put('/api/v1/items/:id', async (req, res) => {
  try {
    const { name } = req.body
    if (!name) return res.status(400).json({ error: 'name is required' })
    const [result] = await pool.query('UPDATE items SET name = ? WHERE id = ?', [name, req.params.id])
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Not found' })
    res.json({ id: Number(req.params.id), name })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})
// GET all teams
app.get('/api/v1/teams', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM teams ORDER BY id DESC')
    res.json(rows)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// GET one team
app.get('/api/v1/teams/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM teams WHERE id = ?', [req.params.id])
    if (rows.length === 0) return res.status(404).json({ error: 'Not found' })
    res.json(rows[0])
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// CREATE team
app.post('/api/v1/teams', async (req, res) => {
  try {
    const { team_name, member1, member2, member3 } = req.body
    if (!team_name || !member1 || !member2 || !member3) {
      return res.status(400).json({ error: 'team_name, member1, member2, member3 are required' })
    }
    const [result] = await pool.query(
      'INSERT INTO teams (team_name, member1, member2, member3) VALUES (?, ?, ?, ?)',
      [team_name, member1, member2, member3]
    )
    res.status(201).json({ id: result.insertId, team_name, member1, member2, member3 })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// UPDATE team
app.put('/api/v1/teams/:id', async (req, res) => {
  try {
    const { team_name, member1, member2, member3 } = req.body
    if (!team_name || !member1 || !member2 || !member3) {
      return res.status(400).json({ error: 'team_name, member1, member2, member3 are required' })
    }
    const [result] = await pool.query(
      'UPDATE teams SET team_name = ?, member1 = ?, member2 = ?, member3 = ? WHERE id = ?',
      [team_name, member1, member2, member3, req.params.id]
    )
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Not found' })
    res.json({ id: Number(req.params.id), team_name, member1, member2, member3 })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

const distPath = path.join(__dirname, 'dist')

app.use(express.static(distPath))

app.get(/.*/, (req, res) => {
  res.sendFile(path.join(distPath, 'index.html'))
})

app.listen(PORT, () => {
  console.log(`API running on port ${PORT}`)
}) 